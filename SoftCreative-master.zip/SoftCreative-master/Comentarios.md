# SoftCreative
Documento integrador de SoftCreative
Dedicado unicamente para diseñadores respecto a formularios (04/03/2020)
